<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Codes extends Model
{
    protected $table = 'codes';
    protected $primaryKey = 'code_id';
}
