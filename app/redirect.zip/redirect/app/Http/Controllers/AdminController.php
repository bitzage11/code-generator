<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Auth;
use App\Codes;
use DB;

class AdminController extends Controller
{
    public function dashboard()
    {
    	$codes = Codes::all();
    	
    	// dd(count($codes));
    	return view('admin.dashboard');
    }

    public function generator(Request $request)
    {
    	DB::connection()->disableQueryLog();

    	$n = $request->code;
    	$array = array();
		for ($i= 0; $i< $n ; $i++){

			$array[$i]['code'] =  strtoupper(str_random(8));
		}
		
		DB::table('codes')->insert($array); 

		return redirect('admin/dashboard')->with('success', 'Code Generated');
    }

    private function generate_random(){
        
        $seed = str_split('ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                     .'0123456789'); // and any other characters
        shuffle($seed); // probably optional since array_is randomized; this may be redundant
        $rand = '';
        foreach (array_rand($seed, 8) as $k) $rand .= $seed[$k];
        
        return $rand;
    }

    public function generateCoupons($count, $length = 8)
    {
        $coupons = [];
        $count2 = 0; 
        while(count($coupons) < $count) {
            do {
                $coupon = strtoupper(str_random($length));
            } while (in_array($coupon, $coupons));
            $coupons[$count2]['code'] = $coupon;
            $count2++;
        }

        return $coupons;
    }
}
